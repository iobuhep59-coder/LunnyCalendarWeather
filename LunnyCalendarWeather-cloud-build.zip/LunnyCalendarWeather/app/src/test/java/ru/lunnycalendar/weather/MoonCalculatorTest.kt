package ru.lunnycalendar.weather

import org.junit.Assert.assertTrue
import org.junit.Test
import ru.lunnycalendar.weather.domain.MoonCalculator
import java.time.LocalDate

class MoonCalculatorTest {
    @Test fun illuminationIsInRange(){ val m=MoonCalculator.info(LocalDate.of(2026,8,12)); assertTrue(m.illumination in 0..100) }
    @Test fun ageIsWithinCycle(){ val m=MoonCalculator.info(LocalDate.of(2026,8,12)); assertTrue(m.age >= 0 && m.age < MoonCalculator.SYNODIC_MONTH) }
    @Test fun knownNewMoonEpoch(){ val m=MoonCalculator.info(LocalDate.of(2000,1,6)); assertTrue(m.age < 0.2 || m.age > MoonCalculator.SYNODIC_MONTH-0.2) }
}
