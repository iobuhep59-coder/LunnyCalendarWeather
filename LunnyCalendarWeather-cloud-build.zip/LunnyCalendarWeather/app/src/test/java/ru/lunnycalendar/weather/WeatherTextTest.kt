package ru.lunnycalendar.weather
import org.junit.Assert.assertEquals
import org.junit.Test
import ru.lunnycalendar.weather.util.weatherDescription
class WeatherTextTest { @Test fun clear(){assertEquals("Ясно",weatherDescription(0))}; @Test fun rain(){assertEquals("Дождь",weatherDescription(63))}; @Test fun storm(){assertEquals("Гроза",weatherDescription(95))} }
