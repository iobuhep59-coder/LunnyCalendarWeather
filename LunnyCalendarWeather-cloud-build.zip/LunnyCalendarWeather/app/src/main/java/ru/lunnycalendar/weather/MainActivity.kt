package ru.lunnycalendar.weather

import android.Manifest
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ru.lunnycalendar.weather.ui.MainViewModel
import ru.lunnycalendar.weather.ui.AppState
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted -> if (granted[Manifest.permission.ACCESS_FINE_LOCATION] == true || granted[Manifest.permission.ACCESS_COARSE_LOCATION] == true) findLocation() }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { val vm: MainViewModel = viewModel(); App(vm) } }
    fun requestLocation() { locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }
    private fun findLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        val location = providers.asSequence().mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
        if (location != null) (application as android.app.Application).let { }
    }
}

@Composable fun App(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    MaterialTheme { Surface(Modifier.fillMaxSize()) { MainScreen(state, vm) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun MainScreen(state: AppState, vm: MainViewModel) {
    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var joke by remember { mutableStateOf(vm.joke) }
    Scaffold(topBar = { TopAppBar(title = { Text("Лунный календарь и погода") }, actions = { TextButton(onClick = { searchOpen = true }) { Text("Город") }; TextButton(onClick = { vm.useDefaultLocation() }) { Text("⌖") } }) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { if (state.offline) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) { Text("Нет подключения к интернету. Показаны сохранённые данные.", Modifier.padding(12.dp)) } } }
            item { ModeTabs(state, vm) }
            item { CalendarCard(state, vm) }
            item { DayCard(state, vm) }
            item { JokeCard(joke) { joke = vm.nextJoke() } }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
    if (searchOpen) SearchDialog(query, { query = it; vm.search(it) }, state.searchResults, { vm.selectPlace(it); searchOpen = false }, { searchOpen = false })
}

@Composable private fun ModeTabs(state: AppState, vm: MainViewModel) { SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) { SegmentedButton(state.mode == "month", { vm.setMode("month") }, shape = SegmentedButtonDefaults.itemShape(0,2)) { Text("Месяц") }; SegmentedButton(state.mode == "week", { vm.setMode("week") }, shape = SegmentedButtonDefaults.itemShape(1,2)) { Text("Неделя") } } }

@Composable private fun CalendarCard(state: AppState, vm: MainViewModel) {
    val days = if (state.mode == "month") vm.monthDays(state.cursor) else vm.weekDays(state.cursor)
    Card { Column(Modifier.padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(vm.periodTitle(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Row { TextButton(onClick = { vm.movePeriod(-1) }) { Text("‹") }; TextButton(onClick = { vm.movePeriod(1) }) { Text("›") } } }
        if (state.mode == "month") Row(Modifier.fillMaxWidth()) { (1..7).forEach { n -> Text(DayOfWeek.of(n).getDisplayName(TextStyle.SHORT, Locale("ru")), Modifier.weight(1f), fontWeight = FontWeight.Bold) } }
        LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.height(if (state.mode == "month") 320.dp else 90.dp), userScrollEnabled = false) { items(days.size) { i -> val d=days[i]; val moon=vm.moon(d); Surface(shape=MaterialTheme.shapes.small, tonalElevation=if(d==state.selected) 4.dp else 0.dp, modifier=Modifier.padding(2.dp).clickable{vm.selectDate(d)}) { Column(Modifier.padding(4.dp), horizontalAlignment=Alignment.CenterHorizontally) { Text("${d.dayOfMonth}", fontWeight=if(d==LocalDate.now()) FontWeight.ExtraBold else FontWeight.Normal); Text(moon.icon, style=MaterialTheme.typography.bodyMedium); Text("${moon.illumination}%", style=MaterialTheme.typography.labelSmall) } } } }
    } }
}

@Composable private fun DayCard(state: AppState, vm: MainViewModel) {
    val d=state.selected; val moon=vm.moon(d); val forecast=vm.forecastFor(d)
    Card { Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Text(d.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("ru"))), style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold)
        Text("${moon.icon} ${moon.name} • ${moon.illumination}% • возраст ${moon.age.format(java.util.Locale.US).let { String.format(java.util.Locale.US,"%.1f",moon.age) }} дн.")
        Text("Ближайшее новолуние: ${vm.moonNextNew(d)}")
        Text("Ближайшее полнолуние: ${vm.moonNextFull(d)}")
        HorizontalDivider()
        if (state.loading) { CircularProgressIndicator(Modifier.size(28.dp)) } else if (forecast != null) {
            Text("${state.place.name}${state.place.region?.let { ", $it" } ?: ""}", fontWeight=FontWeight.SemiBold)
            Text("${vm.weatherText(forecast.code)}  ${forecast.min.toInt()}°…${forecast.max.toInt()}°C")
            Text("Осадки: ${forecast.precipitationProbability}% • ${String.format(Locale.US,"%.1f",forecast.precipitation)} мм")
            Text("Рассвет: ${forecast.sunrise}   Закат: ${forecast.sunset}")
        } else { Text("Прогноз на выбранную дату недоступен. Доступный прогноз обычно охватывает ближайшие 16 дней.") }
        if (state.error != null) { Text(state.error, color=MaterialTheme.colorScheme.error); TextButton(onClick={vm.reload()}){Text("Повторить")} }
    } }
}

@Composable private fun JokeCard(joke:String, next:()->Unit) { Card { Column(Modifier.padding(14.dp)) { Text("Анекдот дня", style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(joke); TextButton(onClick=next){Text("Ещё анекдот")} } } }

@Composable private fun SearchDialog(query:String,onQuery:(String)->Unit,results:List<ru.lunnycalendar.weather.data.Place>,select:(ru.lunnycalendar.weather.data.Place)->Unit,close:()->Unit){ AlertDialog(onDismissRequest=close, title={Text("Выбор города или области")}, text={Column { OutlinedTextField(query,onQuery,Modifier.fillMaxWidth(),label={Text("Город или область")},singleLine=true); Spacer(Modifier.height(8.dp)); if(results.isEmpty()) Text("Введите название и дождитесь результатов.") else results.forEach { p -> ListItem(headlineContent={Text(p.name)}, supportingContent={Text(listOfNotNull(p.region,p.country).joinToString(", "))}, modifier=Modifier.clickable{select(p)}) } }}, confirmButton={TextButton(onClick=close){Text("Закрыть")}}) }
