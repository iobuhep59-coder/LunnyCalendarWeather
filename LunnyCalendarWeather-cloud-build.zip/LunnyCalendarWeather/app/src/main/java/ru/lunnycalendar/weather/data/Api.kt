package ru.lunnycalendar.weather.data

import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherApi {
    @GET("v1/forecast") suspend fun forecast(@Query("latitude") lat: Double, @Query("longitude") lon: Double, @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,sunrise,sunset", @Query("timezone") timezone: String = "auto", @Query("forecast_days") days: Int = 16): WeatherResponse
}
interface GeocodingApi { @GET("v1/search") suspend fun search(@Query("name") name: String, @Query("count") count: Int = 10, @Query("language") language: String = "ru", @Query("format") format: String = "json"): GeoResponse }
