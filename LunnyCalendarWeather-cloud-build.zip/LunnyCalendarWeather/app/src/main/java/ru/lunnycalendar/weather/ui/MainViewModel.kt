package ru.lunnycalendar.weather.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ru.lunnycalendar.weather.data.*
import ru.lunnycalendar.weather.domain.MoonCalculator
import ru.lunnycalendar.weather.domain.MoonInfo
import ru.lunnycalendar.weather.util.Jokes
import ru.lunnycalendar.weather.util.weatherDescription
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class AppState(
    val selected: LocalDate = LocalDate.now(),
    val cursor: LocalDate = LocalDate.now().withDayOfMonth(1),
    val mode: String = "month",
    val place: Place = Place("Москва", "Москва", "Россия", 55.7558, 37.6173, "Europe/Moscow"),
    val forecast: WeatherResponse? = null,
    val searchResults: List<Place> = emptyList(),
    val loading: Boolean = false,
    val offline: Boolean = false,
    val error: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ApiRepository(app.applicationContext)
    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state.asStateFlow()
    var joke: String = Jokes.random(); private set

    init { viewModelScope.launch {
        val saved = repo.loadPlace(); val cached = repo.loadWeather()
        _state.value = _state.value.copy(place=saved ?: _state.value.place, forecast=cached)
        reload()
    } }

    fun search(q: String) { if (q.trim().length < 2) { _state.value=_state.value.copy(searchResults=emptyList()); return }; viewModelScope.launch { try { _state.value=_state.value.copy(loading=true,error=null); _state.value=_state.value.copy(searchResults=repo.searchPlaces(q),loading=false) } catch (e: Exception) { _state.value=_state.value.copy(loading=false,error="Не удалось выполнить поиск. Проверьте интернет-соединение.") } } }
    fun selectPlace(p: Place) { viewModelScope.launch { repo.savePlace(p); _state.value=_state.value.copy(place=p,searchResults=emptyList(),selected=LocalDate.now(),cursor=LocalDate.now().withDayOfMonth(1)); reload() } }
    fun useDefaultLocation() { selectPlace(Place("Москва","Москва","Россия",55.7558,37.6173,"Europe/Moscow")) }
    fun reload() { viewModelScope.launch { try { _state.value=_state.value.copy(loading=true,error=null); val f=repo.getForecast(_state.value.place); _state.value=_state.value.copy(forecast=f,loading=false,offline=false) } catch (_: Exception) { val cached=repo.loadWeather(); _state.value=_state.value.copy(forecast=cached,loading=false,offline=true,error=if(cached==null) "Не удалось загрузить погоду." else null) } } }
    fun setMode(m:String){_state.value=_state.value.copy(mode=m,cursor=if(m=="month")_state.value.selected.withDayOfMonth(1) else _state.value.selected)}
    fun selectDate(d:LocalDate){_state.value=_state.value.copy(selected=d,cursor=if(_state.value.mode=="month")d.withDayOfMonth(1) else d); if(forecastFor(d)==null) reload()}
    fun movePeriod(delta:Int){val s=_state.value; _state.value=s.copy(cursor=if(s.mode=="month")s.cursor.plusMonths(delta.toLong()) else s.cursor.plusWeeks(delta.toLong()))}
    fun monthDays(date:LocalDate):List<LocalDate>{ val ym=YearMonth.from(date); val first=ym.atDay(1); val offset=first.dayOfWeek.value-1; return (0 until (offset+ym.lengthOfMonth()+6)/7*7).map{first.minusDays(offset.toLong()).plusDays(it.toLong())} }
    fun weekDays(date:LocalDate):List<LocalDate>{val start=date.minusDays((date.dayOfWeek.value-1).toLong()); return (0..6).map{start.plusDays(it.toLong())}}
    fun periodTitle():String = if(_state.value.mode=="month") _state.value.cursor.format(DateTimeFormatter.ofPattern("LLLL yyyy",Locale("ru"))).replaceFirstChar{it.uppercase()} else { val w=weekDays(_state.value.cursor); "${w.first().dayOfMonth}–${w.last().dayOfMonth} ${w.last().format(DateTimeFormatter.ofPattern("LLLL yyyy",Locale("ru")))}" }
    fun moon(d:LocalDate):MoonInfo=MoonCalculator.info(d,zone())
    fun moonNextNew(d:LocalDate):String=MoonCalculator.nextNewMoon(d,zone()).format(DateTimeFormatter.ofPattern("d MMMM",Locale("ru")))
    fun moonNextFull(d:LocalDate):String=MoonCalculator.nextFullMoon(d,zone()).format(DateTimeFormatter.ofPattern("d MMMM",Locale("ru")))
    fun forecastFor(d:LocalDate):DailyForecast? { val f=_state.value.forecast?:return null; val i=f.daily.time.indexOf(d.toString()); if(i<0)return null; return DailyForecast(d,f.daily.weather_code[i],f.daily.temperature_2m_max[i],f.daily.temperature_2m_min[i],f.daily.precipitation_sum[i],f.daily.precipitation_probability_max?.getOrNull(i)?:0,f.daily.sunrise[i].substringAfter('T').take(5),f.daily.sunset[i].substringAfter('T').take(5)) }
    fun weatherText(code:Int)=weatherDescription(code)
    fun nextJoke():String{joke=Jokes.random(joke);return joke}
    private fun zone():ZoneId=try{ZoneId.of(_state.value.place.timezone?:ZoneId.systemDefault().id)}catch(_:Exception){ZoneId.systemDefault()}
}
