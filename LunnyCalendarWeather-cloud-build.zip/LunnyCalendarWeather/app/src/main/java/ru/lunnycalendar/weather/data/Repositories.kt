package ru.lunnycalendar.weather.data

import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import android.content.Context
import kotlinx.coroutines.flow.first
import androidx.datastore.preferences.core.edit
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.LocalDate
import retrofit2.Retrofit
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType

private val Context.store by preferencesDataStore("app_cache")
private val json = Json { ignoreUnknownKeys = true }

class ApiRepository(private val context: Context) {
    private val weather = Retrofit.Builder().baseUrl("https://api.open-meteo.com/").addConverterFactory(json.asConverterFactory("application/json".toMediaType())).build().create(WeatherApi::class.java)
    private val geo = Retrofit.Builder().baseUrl("https://geocoding-api.open-meteo.com/").addConverterFactory(json.asConverterFactory("application/json".toMediaType())).build().create(GeocodingApi::class.java)
    private val placeKey = stringPreferencesKey("place")
    private val weatherKey = stringPreferencesKey("weather")

    suspend fun searchPlaces(q: String): List<Place> = geo.search(q).results.orEmpty().map { Place(it.name, it.admin1, it.country, it.latitude, it.longitude, it.timezone) }

    suspend fun getForecast(place: Place): WeatherResponse = weather.forecast(place.latitude, place.longitude).also { saveWeather(it) }
    suspend fun savePlace(place: Place) { context.store.edit { it[placeKey] = json.encodeToString(place) } }
    suspend fun loadPlace(): Place? = context.store.data.first()[placeKey]?.let { json.decodeFromString<Place>(it) }
    suspend fun saveWeather(value: WeatherResponse) { context.store.edit { it[weatherKey] = json.encodeToString(value) } }
    suspend fun loadWeather(): WeatherResponse? = context.store.data.first()[weatherKey]?.let { json.decodeFromString<WeatherResponse>(it) }
}
