package ru.lunnycalendar.weather.domain

import java.time.*
import kotlin.math.*

data class MoonInfo(val phase: Double, val illumination: Int, val age: Double, val name: String, val icon: String)

object MoonCalculator {
    private val epoch = Instant.parse("2000-01-06T18:14:00Z")
    const val SYNODIC_MONTH = 29.530588853

    fun info(date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): MoonInfo {
        val instant = date.atTime(12, 0).atZone(zone).toInstant()
        val days = Duration.between(epoch, instant).toMillis() / 86_400_000.0
        var age = days % SYNODIC_MONTH
        if (age < 0) age += SYNODIC_MONTH
        val phase = age / SYNODIC_MONTH
        val illum = ((1.0 - cos(2.0 * Math.PI * phase)) / 2.0 * 100.0).roundToInt()
        val (name, icon) = when {
            phase < 0.03 || phase > 0.97 -> "Новолуние" to "●"
            phase < 0.22 -> "Растущий серп" to "🌒"
            phase < 0.28 -> "Первая четверть" to "🌓"
            phase < 0.47 -> "Растущая Луна" to "🌔"
            phase < 0.53 -> "Полнолуние" to "🌕"
            phase < 0.72 -> "Убывающая Луна" to "🌖"
            phase < 0.78 -> "Последняя четверть" to "🌗"
            else -> "Убывающий серп" to "🌘"
        }
        return MoonInfo(phase, illum, age, name, icon)
    }

    fun nextNewMoon(date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): LocalDate = nextPhase(date, 0.0, zone)
    fun nextFullMoon(date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): LocalDate = nextPhase(date, 0.5, zone)

    private fun nextPhase(date: LocalDate, target: Double, zone: ZoneId): LocalDate {
        var d = date
        repeat(60) {
            val p = info(d, zone).phase
            val distance = if (target == 0.0) min(p, 1.0 - p) else abs(p - target)
            if (distance < 0.018) return d
            d = d.plusDays(1)
        }
        return d
    }
}
