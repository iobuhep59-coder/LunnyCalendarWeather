package ru.lunnycalendar.weather.data

import kotlinx.serialization.Serializable

@Serializable data class GeoResponse(val results: List<GeoResult>? = null)
@Serializable data class GeoResult(val id: Long? = null, val name: String, val latitude: Double, val longitude: Double, val country: String? = null, val admin1: String? = null, val timezone: String? = null)
@Serializable data class WeatherResponse(val daily: DailyWeather)
@Serializable data class DailyWeather(
    val time: List<String>,
    val weather_code: List<Int>,
    val temperature_2m_max: List<Double>,
    val temperature_2m_min: List<Double>,
    val precipitation_sum: List<Double>,
    val precipitation_probability_max: List<Int?>? = null,
    val sunrise: List<String>,
    val sunset: List<String>
)

@Serializable data class Place(val name: String, val region: String?, val country: String?, val latitude: Double, val longitude: Double, val timezone: String?)
data class DailyForecast(val date: java.time.LocalDate, val code: Int, val max: Double, val min: Double, val precipitation: Double, val precipitationProbability: Int, val sunrise: String, val sunset: String)
